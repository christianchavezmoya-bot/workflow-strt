var be=Object.defineProperty;var he=(i,r,c)=>r in i?be(i,r,{enumerable:!0,configurable:!0,writable:!0,value:c}):i[r]=c;var $=(i,r,c)=>he(i,typeof r!="symbol"?r+"":r,c);(function(){"use strict";const i="screenshots/hero",r="screenshots/mobile",c="videos",D=["Create Project","Add Assets","Start Run","Complete Steps","Capture Photos","Log Issue","Phone Upload","Sign Off"],p=[{id:1,section:"welcome",layout:"hero",audio:"audio/scene-01.mp3",tag:"Welcome",title:"Strata Workflow App",subtitle:"Field operations for telecom & utility project management",bullets:["Track projects · install & inspect assets on site","Guided workflows with photos, signatures, issues & reports","One React bundle — web, Android, iOS — plus ASP.NET Core API"],shots:[{src:`${i}/dashboard.png`,label:"Operations dashboard"}]},{id:2,section:"overview",layout:"architecture",audio:"audio/scene-02.mp3",tag:"Platform",title:"One App, Three Deployments",subtitle:"Same experience everywhere your teams work",bullets:["Web — React 18 + TypeScript + MUI v5, Vite, Redux","Mobile — same bundle in Capacitor 8 (Android + iOS)","Backend — ASP.NET Core 8 + EF Core + SQLite, JWT :4000"]},{id:3,section:"overview",layout:"compare",audio:"audio/scene-03.mp3",tag:"Projects",title:"Projects",subtitle:"Top-level container for every job",bullets:["Assets, contacts, inspections, documents & delivery profiles","Browse, open a detail page, manage status & linked assets"],shots:[{src:`${i}/projects.png`,label:"Projects list",variant:"desktop"},{src:`${r}/projects.png`,label:"Mobile projects",variant:"phone"}]},{id:4,section:"overview",layout:"hero",audio:"audio/scene-04.mp3",tag:"Assets",title:"Assets & Installations",subtitle:"The main field-work surface",bullets:["Workflow assignments · status Not Started → Complete","Documents, inspection history, run history per asset","Technicians pick a project, find equipment, press Start Run"],shots:[{src:`${i}/assets-expanded.png`,label:"Project assets — expanded row"}]},{id:5,section:"overview",layout:"compare",audio:"audio/scene-05.mp3",tag:"Workflows",title:"Guided Workflows",subtitle:"WorkOrderRunner — the heart of on-site work",bullets:["Photos/video, text, checkbox, QR, time tracking","Blocking issues prevent completion (HTTP 422)","Signatures on-device or via email link · PDF reports"],shots:[{src:`${i}/work-instructions.png`,label:"Work instructions",variant:"desktop"},{src:`${i}/runner-step.png`,label:"Step-by-step runner",variant:"desktop"}]},{id:6,section:"overview",layout:"hero",audio:"audio/scene-06.mp3",tag:"Dashboard",title:"Operations Dashboard",subtitle:"Office-scoped visibility & quick actions",bullets:["Open issues, pending signatures, technician workload","Evidence completeness & workflow health","Resume runs or upload missing photos in one click"],shots:[{src:`${i}/dashboard.png`,label:"Operations dashboard"}]},{id:7,section:"overview",layout:"hero",audio:"audio/scene-07.mp3",tag:"Issues",title:"Issues Board",subtitle:"Cross-project issue tracking",bullets:["Kanban-style view of every asset issue","Track, assign & resolve blocking and non-blocking problems"],shots:[{src:`${i}/issues.png`,label:"Issues board"}]},{id:8,section:"overview",layout:"grid",audio:"audio/scene-08.mp3",tag:"Supporting",title:"Supporting Modules",subtitle:"Documents, admin, mobile upload & more",bullets:["Documents · Tips & tricks · Admin (users, sites, registry)","Settings, 2FA · Mobile Upload QR flow · BOM module (flagged)"],shots:[{src:`${i}/documents.png`,label:"Documents"},{src:`${i}/admin.png`,label:"Admin console"},{src:`${i}/settings.png`,label:"Settings"},{src:`${i}/tips.png`,label:"Tips & tricks"}]},{id:9,section:"journey",layout:"video",audio:"audio/scene-09.mp3",tag:"User Journey",title:"Step 1 — Create a Project",subtitle:"Set up the top-level job container",journeyStep:1,bullets:["Open Projects → Create project","Enter job number, customer, site & workflow mode","Save — the project is ready for assets"],video:`${c}/journey-create-project.mp4`},{id:10,section:"journey",layout:"journey",audio:"audio/scene-10.mp3",tag:"User Journey",title:"Step 2 — Add Assets",subtitle:"Register equipment on the project",journeyStep:2,bullets:["Open Assets, filter by your project","Add assets with tag, serial, model & location","Assign the workflow that applies to each asset"],shots:[{src:`${i}/assets.png`,label:"Project assets"}]},{id:11,section:"journey",layout:"video",audio:"audio/scene-11.mp3",tag:"User Journey",title:"Step 3 — Start Run",subtitle:"Launch the guided workflow",journeyStep:3,bullets:["Find the asset and click Start Run","Confirm the Run workflow setup dialog","WorkOrderRunner opens on the first step"],video:`${c}/journey-workflow-run.mp4`},{id:12,section:"journey",layout:"journey",audio:"audio/scene-12.mp3",tag:"User Journey",title:"Step 4 — Complete Steps",subtitle:"Follow the guided checklist",journeyStep:4,bullets:["Each step shows instructions & capture fields","Tick checkboxes, enter readings, scan QR codes","Time tracking runs; progress saves automatically"],shots:[{src:`${i}/runner-step.png`,label:"Runner — Step 1 of 4"}]},{id:13,section:"journey",layout:"journey",audio:"audio/scene-13.mp3",tag:"User Journey",title:"Step 5 — Capture Photos",subtitle:"Evidence on every step",journeyStep:5,bullets:["Tap Photo / Video on steps that require media","Use the camera or gallery — files attach to the run","Missing captures are flagged before completion"],shots:[{src:`${i}/runner-step.png`,label:"Photo capture step"}]},{id:14,section:"journey",layout:"journey",audio:"audio/scene-14.mp3",tag:"User Journey",title:"Step 6 — Log an Issue",subtitle:"Flag blocking or observation issues",journeyStep:6,bullets:["Flag issue on any step — blocking, observation, scope deviation","Add description, severity & optional photo","Blocking issues must be resolved before completion"],shots:[{src:`${i}/issues.png`,label:"Issues board entry"}]},{id:15,section:"journey",layout:"video",audio:"audio/scene-15.mp3",tag:"User Journey",title:"Step 7 — Add Photo from Phone",subtitle:"QR mobile upload flow",journeyStep:7,bullets:["Generate a QR code from the dashboard or runner","Scan with any phone — no app install needed","The photo uploads straight to the pending run"],video:`${c}/journey-mobile-upload.mp4`,videoVariant:"phone"},{id:16,section:"journey",layout:"journey",audio:"audio/scene-16.mp3",tag:"User Journey",title:"Step 8 — Complete & Sign Off",subtitle:"Finish the run",journeyStep:8,bullets:["Review summary — captures, issues & time entries","Installer & customer signatures (device or email link)","Run locks · PDF report generates · dashboard updates"],shots:[{src:`${i}/project-detail.png`,label:"Project detail & sign-off"}]},{id:17,section:"platform",layout:"compare",audio:"audio/scene-17.mp3",tag:"Offline",title:"Offline-First Mobile",subtitle:"Built for real field conditions",bullets:["Prefetch projects, assets, configs & media into IndexedDB","Writes queue offline · sync on reconnect (409/412 conflicts)","Photos & signatures on Capacitor Filesystem via mediaStore"],shots:[{src:`${r}/dashboard.png`,label:"Mobile dashboard",variant:"phone"},{src:`${r}/assets.png`,label:"Mobile assets",variant:"phone"}]},{id:18,section:"platform",layout:"architecture",audio:"audio/scene-18.mp3",tag:"Architecture",title:"Architecture",subtitle:"How the system fits together",bullets:["features/ → services/ → repositories/ → Redux store","Flat REST controllers · projectId query param · ~98 migrations","JWT short claims · two-tier permissions · biometric on native"]},{id:19,section:"platform",layout:"hero",audio:"audio/scene-19.mp3",tag:"Enterprise",title:"Enterprise & Dev Stack",subtitle:"Secure, scalable, audit-ready",bullets:["User management, brand settings, role-based access, audit records","npm run dev :5173 · dotnet run :4000 (Swagger) · Playwright e2e","SQLite WAL · SSE live updates across connected clients"],shots:[{src:`${i}/admin.png`,label:"Admin & user management"}]},{id:20,section:"cta",layout:"hero",audio:"audio/scene-20.mp3",tag:"Next Steps",title:"Transform Field Operations",subtitle:"From first project to final sign-off",bullets:["Office planners & field technicians in one trusted system","Ready for a live walkthrough on your projects?"],shots:[{src:`${i}/project-detail.png`,label:"Active project"}]}],k=p.length,P={welcome:"Welcome",overview:"Product Overview",journey:"Live User Journey",platform:"Platform & Architecture",cta:"Next Steps"},q={1:17e3,2:17e3,3:15e3,4:16e3,5:17e3,6:15e3,7:13e3,8:15e3,9:16e3,10:15e3,11:17e3,12:15e3,13:15e3,14:16e3,15:16e3,16:16e3,17:18e3,18:19e3,19:17e3,20:13e3};function W(e){try{return new URL(e,document.baseURI).href}catch{return e}}class N{constructor(){$(this,"tracks",new Map);$(this,"activeId",null)}async loadAll(t){await Promise.all(t.map(n=>this.loadTrack(n)))}loadTrack(t){return this.tracks.has(t.id)?Promise.resolve():new Promise(n=>{const o=new Audio(W(t.audio));o.preload="auto";const a=()=>{this.tracks.set(t.id,o),n()};o.addEventListener("canplaythrough",a,{once:!0}),o.addEventListener("error",a,{once:!0}),o.load(),setTimeout(a,12e3)})}getTrack(t){return this.tracks.get(t)}stop(){const t=this.activeId!=null?this.tracks.get(this.activeId):null;t&&(t.pause(),t.currentTime=0,t.onended=null,t.onerror=null),this.activeId=null}async play(t){this.stop();const n=this.tracks.get(t);if(!n)return null;this.activeId=t,n.currentTime=0,n.readyState<HTMLMediaElement.HAVE_FUTURE_DATA&&await new Promise(o=>{const a=()=>o();n.addEventListener("canplaythrough",a,{once:!0}),n.addEventListener("error",a,{once:!0}),n.load(),setTimeout(a,5e3)});try{return await n.play(),n}catch{return this.activeId=null,null}}get active(){return this.activeId!=null?this.tracks.get(this.activeId)??null:null}}const l=new N;function w(e,t=""){return`
    <figure class="shot shot--${e.variant??"desktop"} ${t}">
      <div class="shot-chrome">
        <span class="shot-dot"></span><span class="shot-dot"></span><span class="shot-dot"></span>
        <span class="shot-label">${e.label}</span>
      </div>
      <div class="shot-body">
        <img class="shot-img" src="${e.src}" alt="${e.label}" loading="eager" decoding="async" />
      </div>
    </figure>`}function E(e){var n;const t=(n=e.shots)==null?void 0:n[0];return t?`<div class="visual visual--hero">${w(t,"shot--hero")}</div>`:""}function J(e){return`<div class="visual visual--compare">${(e.shots??[]).map(n=>w(n)).join("")}</div>`}function V(e){return`<div class="visual visual--grid">${(e.shots??[]).slice(0,4).map(n=>w(n)).join("")}</div>`}function _(e){if(!e.video)return E(e);const t=e.videoVariant??"desktop";return`
    <div class="visual visual--video visual--video-${t}">
      <figure class="shot shot--${t} shot--video">
        <div class="shot-chrome">
          <span class="shot-dot"></span><span class="shot-dot"></span><span class="shot-dot"></span>
          <span class="shot-label">Live screen recording</span>
        </div>
        <div class="shot-body">
          <video class="shot-video" src="${e.video}" muted playsinline preload="auto" loop></video>
        </div>
      </figure>
    </div>`}function H(e=!1){return`
    <div class="${e?"arch arch--compact":"arch"}" aria-label="System architecture">
      <div class="arch-tier arch-tier--clients">
        <button class="arch-node" data-arch="web" type="button">🖥️ Web Browser<span>React SPA</span></button>
        <button class="arch-node" data-arch="android" type="button">🤖 Android<span>Capacitor 8</span></button>
        <button class="arch-node" data-arch="ios" type="button">📱 iOS<span>Capacitor 8</span></button>
      </div>
      <div class="arch-flow">▼</div>
      <button class="arch-box arch-box--react" data-arch="react" type="button">
        <strong>React App</strong>
        <span>features/ → services/ → repositories/ → Redux</span>
        <span class="arch-sub">IndexedDB + Filesystem (native offline)</span>
      </button>
      <div class="arch-flow">▼ &nbsp;REST + SSE&nbsp; ▲</div>
      <button class="arch-box arch-box--api" data-arch="api" type="button">
        <strong>ASP.NET Core API</strong>
        <span>Flat controllers · EF Core + SQLite (WAL) · JWT :4000</span>
      </button>
      <div class="arch-tier arch-tier--offline">
        <span class="arch-chip">useSyncEngine → queue</span>
        <span class="arch-chip">mediaStore photos</span>
        <span class="arch-chip">409/412 conflict resolve</span>
        <span class="arch-chip">biometric lock</span>
      </div>
    </div>`}function Q(e){return`<div class="work-tree" aria-label="User journey work tree">${D.map((n,o)=>{const a=o+1;return`
      <button class="wt-node ${e==null?"":a<e?"is-done":a===e?"is-active":"is-pending"}" data-journey-step="${a}" type="button" title="Step ${a}: ${n}">
        <span class="wt-num">${a}</span>
        <span class="wt-label">${n}</span>
      </button>`}).join('<span class="wt-link"></span>')}</div>`}function X(e){var t;return(t=e.bullets)!=null&&t.length?`<ul class="scene-bullets">${e.bullets.map(n=>`<li>${n}</li>`).join("")}</ul>`:""}function G(e){switch(e.layout){case"architecture":return`<div class="visual visual--arch">${H(!1)}</div>`;case"compare":return J(e);case"grid":return V(e);case"video":return _(e);case"journey":return E(e);case"hero":default:return E(e)}}function K(e){const t=P[e.section]??e.section,n=e.section==="journey",o=`
    <div class="scene-left">
      ${X(e)}
      ${n?Q(e.journeyStep):""}
    </div>`,a=G(e);return`
    <div class="scene-inner scene-inner--${e.layout}" data-scene-id="${e.id}" data-section="${e.section}">
      <header class="scene-copy">
        <div class="scene-copy-tags">
          <span class="scene-section">${t}</span>
          <span class="scene-tag">${e.tag}</span>
        </div>
        <h2 class="scene-title">${e.title}</h2>
        <p class="scene-subtitle">${e.subtitle}</p>
      </header>
      <div class="scene-body">
        ${o}
        <div class="scene-right">${a}</div>
      </div>
    </div>`}function Y(){return`
    <section class="screen screen--opening" id="opening-screen">
      <div class="opening-bg"></div>
      <div class="opening-content">
        <div class="brand-mark">S</div>
        <p class="eyebrow">Customer Presentation · v5</p>
        <h1 class="opening-title">Strata Workflow App</h1>
        <p class="opening-lead">Product overview + a live, recorded user journey — create a project, run a workflow, capture photos, log issues, and upload from a phone.</p>
        <div class="opening-toc">
          <span>Overview</span><span>8-step journey videos</span><span>Architecture</span>
        </div>
        <div class="opening-actions">
          <button type="button" class="btn btn-primary" id="btn-start">Start Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-journey">Watch User Journey</button>
          <button type="button" class="btn btn-secondary" id="btn-start-muted">Silent mode</button>
        </div>
        <p class="opening-note"><strong>v5 · 20 scenes with video</strong> — if you see "1 / 13", delete the old folder and download v5.<br/>Use Start-Presentation.bat if the page is blank.</p>
      </div>
    </section>`}function z(){return`
    <footer class="controls" id="controls" hidden>
      <div class="controls-left">
        <button type="button" class="ctrl-btn" id="btn-prev" aria-label="Previous scene">←</button>
        <button type="button" class="ctrl-btn" id="btn-play" aria-label="Pause presentation">❚❚</button>
        <button type="button" class="ctrl-btn" id="btn-next" aria-label="Next scene">→</button>
      </div>
      <div class="controls-center">
        <div class="progress-track"><div class="progress-fill" id="progress-fill"></div></div>
        <div class="scene-dots" id="scene-dots"></div>
      </div>
      <div class="controls-right">
        <span class="scene-counter" id="scene-counter">1 / 20</span>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-mute" aria-label="Mute narration">Mute</button>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-restart" aria-label="Restart">Restart</button>
      </div>
    </footer>`}function Z(){return`
    <section class="screen screen--presentation" id="presentation-screen" hidden>
      <header class="topbar">
        <div class="topbar-brand"><span class="brand-dot"></span> Strata Workflow App</div>
        <div class="topbar-meta" id="topbar-section">Sales Demonstration</div>
      </header>
      <main class="stage" id="stage"></main>
      ${z()}
    </section>`}function ee(){return`
    <div class="end-overlay" id="end-overlay">
      <div class="end-card">
        <h3>Thank you</h3>
        <p>Strata Workflow App connects office planners and field technicians — from creating a project through running workflows, capturing evidence, resolving issues, and signed deliverables.</p>
        <div class="end-actions">
          <button type="button" class="btn btn-primary" id="btn-replay">Replay Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-explore">Explore Scenes</button>
        </div>
      </div>
    </div>`}function te(e){const t=document.getElementById("topbar-section");t&&(t.textContent=e)}const s={started:!1,mode:"audio",sceneIndex:0,playing:!1,muted:!1,ended:!1,userPaused:!1,playToken:0},x=p.findIndex(e=>e.section==="journey");let b=null,u=0,L=0;const se=document.getElementById("app");function m(){b&&(clearTimeout(b),b=null)}function ne(){se.innerHTML=Y()+Z()+ee(),ae(),ie(),re(),ce()}function h(){document.getElementById("end-overlay").classList.remove("is-visible")}function oe(){document.getElementById("end-overlay").classList.add("is-visible")}function ae(){var n;const e=document.getElementById("btn-start"),t=document.getElementById("btn-start-muted");e.addEventListener("click",async()=>{e.disabled=!0,e.textContent="Loading narration…",await j("audio"),e.disabled=!1,e.textContent="Start Presentation"}),t.addEventListener("click",()=>void j("muted")),(n=document.getElementById("btn-journey"))==null||n.addEventListener("click",async()=>{await j("audio"),x>=0&&d(x,!0)})}async function j(e){s.started=!0,s.mode=e,s.muted=e==="muted",s.sceneIndex=0,s.playing=!0,s.ended=!1,s.userPaused=!1,s.playToken++,document.getElementById("opening-screen").hidden=!0,document.getElementById("presentation-screen").hidden=!1,document.getElementById("controls").hidden=!1,h(),e==="audio"&&!s.muted&&await l.loadAll(p),F(),y(0,!0)}function ie(){const e=document.getElementById("scene-dots");e.innerHTML=p.map((t,n)=>`<button type="button" class="scene-dot" data-index="${n}" aria-label="Scene ${n+1}"></button>`).join(""),e.querySelectorAll(".scene-dot").forEach(t=>{t.addEventListener("click",()=>d(Number(t.dataset.index),!0))})}function re(){document.getElementById("btn-prev").addEventListener("click",()=>d(s.sceneIndex-1,!0)),document.getElementById("btn-next").addEventListener("click",()=>d(s.sceneIndex+1,!0)),document.getElementById("btn-play").addEventListener("click",C),document.getElementById("btn-mute").addEventListener("click",O),document.getElementById("btn-restart").addEventListener("click",T),document.getElementById("btn-replay").addEventListener("click",T),document.getElementById("btn-explore").addEventListener("click",()=>{s.ended=!1,h(),s.playing=!1,f()}),window.addEventListener("keydown",e=>{s.started&&(e.key==="ArrowRight"||e.key===" "?(e.preventDefault(),s.ended?T():d(s.sceneIndex+1,!0)):e.key==="ArrowLeft"?d(s.sceneIndex-1,!0):e.key==="p"||e.key==="P"?C():(e.key==="m"||e.key==="M")&&O())})}function ce(){const e=document.getElementById("stage");e.addEventListener("touchstart",t=>{var n;L=((n=t.changedTouches[0])==null?void 0:n.clientX)??0},{passive:!0}),e.addEventListener("touchend",t=>{var o;if(!s.started)return;const n=(((o=t.changedTouches[0])==null?void 0:o.clientX)??0)-L;Math.abs(n)<50||d(s.sceneIndex+(n<0?1:-1),!0)},{passive:!0})}function le(){document.querySelectorAll(".wt-node").forEach(e=>{e.addEventListener("click",()=>{const t=Number(e.dataset.journeyStep),n=p.findIndex(o=>o.journeyStep===t);n>=0&&d(n,!0)})}),document.querySelectorAll(".arch-node, .arch-box").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".arch-node, .arch-box").forEach(t=>t.classList.remove("is-focus")),e.classList.add("is-focus")})})}function B(){const e=document.querySelector(".shot-video");e&&(e.currentTime=0,e.play().catch(()=>{}))}function A(){document.querySelectorAll(".shot-video").forEach(e=>e.pause())}function v(){return p[s.sceneIndex]}function d(e,t=!1){if(!(e<0)){if(e>=k){R();return}t&&(s.userPaused=!s.playing),y(e,t||s.playing)}}function y(e,t){m(),l.stop(),A(),cancelAnimationFrame(u),s.playToken++,s.sceneIndex=e,s.ended=!1,h();const n=v(),o=document.getElementById("stage");o.innerHTML=K(n),le(),pe(),me(),te(P[n.section]??"Sales Demonstration"),S(0),requestAnimationFrame(()=>{var a;return(a=o.querySelector(".scene-inner"))==null?void 0:a.classList.add("is-visible")}),B(),t&&s.playing&&!s.userPaused&&g(n,s.playToken)}async function g(e,t){m(),l.stop();const n=q[e.id]??16e3,o=()=>{t===s.playToken&&ue(500)};if(s.mode==="audio"&&!s.muted){const a=await l.play(e.id);if(t!==s.playToken)return;a?(a.onended=o,a.onerror=()=>I(n,o,t),de(a,t)):I(n,o,t)}else I(n,o,t)}function de(e,t){const n=()=>{if(t!==s.playToken)return;const o=e.duration;Number.isFinite(o)&&o>0&&S(e.currentTime/o),u=requestAnimationFrame(n)};u=requestAnimationFrame(n)}function I(e,t,n){const o=performance.now(),a=M=>{if(n!==s.playToken)return;if(!s.playing||s.userPaused){u=requestAnimationFrame(a);return}const U=Math.min(1,(M-o)/e);S(U),U>=1?t():u=requestAnimationFrame(a)};u=requestAnimationFrame(a)}function ue(e){m(),!(!s.playing||s.userPaused)&&(b=setTimeout(()=>{s.sceneIndex>=k-1?R():y(s.sceneIndex+1,!0)},e))}function R(){s.ended=!0,s.playing=!1,m(),l.stop(),A(),S(1),f(),oe()}function T(){s.ended=!1,s.playing=!0,s.userPaused=!1,h(),f(),y(0,!0)}function C(){if(!s.ended)if(s.playing=!s.playing,s.userPaused=!s.playing,f(),s.playing){B();const e=l.active;e&&!s.muted?e.play().catch(()=>g(v(),++s.playToken)):g(v(),++s.playToken)}else m(),l.stop(),A(),cancelAnimationFrame(u)}function O(){s.mode==="muted"?(s.mode="audio",s.muted=!1):s.muted=!s.muted,F(),s.muted?l.stop():s.playing&&!s.userPaused&&g(v(),++s.playToken)}function F(){const e=document.getElementById("btn-mute"),t=s.mode==="muted"||s.muted;e.textContent=t?"Unmute":"Mute",e.classList.toggle("is-muted",t)}function f(){document.getElementById("btn-play").textContent=s.playing?"❚❚":"▶"}function pe(){document.querySelectorAll(".scene-dot").forEach((e,t)=>{e.classList.toggle("is-active",t===s.sceneIndex),e.classList.toggle("is-done",t<s.sceneIndex)})}function me(){document.getElementById("scene-counter").textContent=`${s.sceneIndex+1} / ${k}`}function S(e){document.getElementById("progress-fill").style.width=`${Math.max(0,Math.min(100,e*100))}%`}ne()})();
