(function(){"use strict";const o="screenshots",m=[{id:1,audio:"audio/scene-01.mp3",title:"Strata Workflow App",subtitle:"Field Operations, Unified",tag:"Welcome",visual:"hero",screens:{primary:`${o}/desktop-dashboard.png`,layout:"single"}},{id:2,audio:"audio/scene-02.mp3",title:"The Challenge",subtitle:"Fragmented field work costs time and trust",tag:"Problem",visual:"challenge",screens:{primary:`${o}/desktop-issues.png`,layout:"single"},hotspots:[{id:"paper",label:"Lost checklists",detail:"Paper processes create gaps and rework.",x:18,y:38},{id:"photos",label:"Scattered photos",detail:"Evidence trapped on personal devices.",x:50,y:28},{id:"issues",label:"Missed issues",detail:"Problems discovered too late in the cycle.",x:78,y:42}]},{id:3,audio:"audio/scene-03.mp3",title:"One Platform, Every Device",subtitle:"Web, Android, and iOS — one experience",tag:"Platform",visual:"platforms",screens:{primary:`${o}/desktop-dashboard.png`,secondary:`${o}/mobile-dashboard.png`,layout:"split-platforms"},hotspots:[{id:"web",label:"Desktop web",detail:"Planners and managers work from the office.",x:22,y:55},{id:"mobile",label:"Mobile apps",detail:"Technicians use the same app in the field.",x:72,y:55}]},{id:4,audio:"audio/scene-04.mp3",title:"Projects",subtitle:"Your operational command center",tag:"Projects",visual:"projects",screens:{primary:`${o}/desktop-projects.png`,layout:"single"}},{id:5,audio:"audio/scene-05.mp3",title:"Assets",subtitle:"Where field work happens",tag:"Assets",visual:"assets",screens:{primary:`${o}/desktop-assets.png`,layout:"single"},hotspots:[{id:"status",label:"Live status",detail:"Track progress from Not Started to Complete.",x:30,y:62},{id:"run",label:"Start Run",detail:"Launch the right workflow for each asset.",x:68,y:48}]},{id:6,audio:"audio/scene-06.mp3",title:"Guided Workflows",subtitle:"Step-by-step excellence in the field",tag:"Workflows",visual:"workflow",screens:{primary:`${o}/desktop-assets.png`,layout:"single"},hotspots:[{id:"photo",label:"Photos",detail:"Capture evidence at every step.",x:20,y:50},{id:"time",label:"Time tracking",detail:"Productive and downtime logged automatically.",x:50,y:65},{id:"sign",label:"Signatures",detail:"Sign off runs with confidence.",x:78,y:50}]},{id:7,audio:"audio/scene-07.mp3",title:"Issues & Dashboard",subtitle:"Real-time operational visibility",tag:"Visibility",visual:"dashboard",screens:{primary:`${o}/desktop-dashboard.png`,layout:"single"}},{id:8,audio:"audio/scene-08.mp3",title:"Signatures & Reports",subtitle:"Trusted evidence, delivered",tag:"Compliance",visual:"signatures",screens:{primary:`${o}/desktop-work-instructions.png`,layout:"single"}},{id:9,audio:"audio/scene-09.mp3",title:"Documents & Knowledge",subtitle:"The right information, everywhere",tag:"Knowledge",visual:"documents",screens:{primary:`${o}/desktop-documents.png`,layout:"single"}},{id:10,audio:"audio/scene-10.mp3",title:"Built for the Field",subtitle:"Offline-first on mobile",tag:"Offline",visual:"offline",screens:{primary:`${o}/mobile-assets.png`,layout:"phone"},hotspots:[{id:"sync",label:"Sync online",detail:"Data prefetches while connected.",x:28,y:40},{id:"queue",label:"Queue offline",detail:"Work continues; changes sync on reconnect.",x:72,y:40}]},{id:11,audio:"audio/scene-11.mp3",title:"Enterprise Ready",subtitle:"Secure, scalable, accountable",tag:"Enterprise",visual:"enterprise",screens:{primary:`${o}/desktop-admin.png`,layout:"single"}},{id:12,audio:"audio/scene-12.mp3",title:"Transform Your Field Operations",subtitle:"From first install to final sign-off",tag:"Next Steps",visual:"cta",screens:{primary:`${o}/desktop-projects.png`,layout:"single"}}],f=m.length,D={1:14500,2:19300,3:17e3,4:15700,5:16750,6:16e3,7:13900,8:13900,9:13250,10:17650,11:14250,12:15450};function O(e,n){return n??e.replace("workflow-runner","assets").replace("desktop-workflow-runner","desktop-assets")}function g(e,n,s){return`
    <figure class="${s==="phone"?"app-shot app-shot--phone":"app-shot app-shot--desktop"}">
      <div class="app-shot-chrome">
        <span class="app-shot-dot"></span><span class="app-shot-dot"></span><span class="app-shot-dot"></span>
        <span class="app-shot-label">${n}</span>
      </div>
      <img class="app-shot-img" src="${e}" alt="${n}" loading="eager" decoding="async"
           onerror="this.dataset.fallback&&(this.src=this.dataset.fallback)"
           data-fallback="${O(e)}" />
    </figure>`}function R(e){const n=e.screens;return n!=null&&n.primary?n.layout==="split-platforms"&&n.secondary?`
      <div class="app-preview app-preview--split">
        ${g(n.primary,"Desktop web app","desktop")}
        ${g(n.secondary,"Mobile app","phone")}
      </div>`:n.layout==="phone"?`
      <div class="app-preview app-preview--phone-center">
        ${g(n.primary,"Mobile field app","phone")}
      </div>`:`
    <div class="app-preview app-preview--desktop">
      ${g(n.primary,"Strata Workflow App","desktop")}
    </div>`:W(e)}function q(e){const n={hero:'<svg viewBox="0 0 120 120" class="viz-icon viz-icon--fallback"><circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" stroke-width="3" opacity=".3"/><path d="M36 72 L60 36 L84 72 Z" fill="currentColor" opacity=".9"/></svg>',cta:'<svg viewBox="0 0 120 120" class="viz-icon viz-icon--fallback"><circle cx="60" cy="60" r="40" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M48 60 L58 70 L76 48" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg>'};return n[e]??n.hero}function W(e){return`
    <div class="scene-visual scene-visual--${e.visual}" data-visual="${e.visual}">
      <div class="viz-glow"></div>
      ${q(e.visual)}
    </div>`}function N(e){const n=e.hotspots?`<div class="hotspots">${e.hotspots.map(s=>`
          <button type="button" class="hotspot" style="left:${s.x}%;top:${s.y}%" data-hotspot="${s.id}" aria-label="${s.label}">
            <span class="hotspot-dot"></span>
            <span class="hotspot-card">
              <strong>${s.label}</strong>
              <em>${s.detail}</em>
            </span>
          </button>`).join("")}</div>`:"";return`
    <div class="scene-visual scene-visual--${e.visual} scene-visual--app" data-visual="${e.visual}">
      ${R(e)}
      ${n}
    </div>`}function j(e){return`
    <div class="scene-inner" data-scene-id="${e.id}">
      <div class="scene-copy">
        <span class="scene-tag">${e.tag}</span>
        <h2 class="scene-title">${e.title}</h2>
        <p class="scene-subtitle">${e.subtitle}</p>
      </div>
      ${N(e)}
    </div>`}function U(){return`
    <section class="screen screen--opening" id="opening-screen">
      <div class="opening-bg"></div>
      <div class="opening-content">
        <div class="brand-mark">S</div>
        <p class="eyebrow">Customer Presentation</p>
        <h1 class="opening-title">Strata Workflow App</h1>
        <p class="opening-lead">Field operations platform for telecom &amp; utility teams</p>
        <div class="opening-actions">
          <button type="button" class="btn btn-primary" id="btn-start">Start Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-start-muted">Start without audio</button>
        </div>
        <p class="opening-note">Tap Start to enable narration and automatic scene progression.<br/>Best experienced in full screen.</p>
      </div>
    </section>`}function H(){return`
    <footer class="controls" id="controls" hidden>
      <div class="controls-left">
        <button type="button" class="ctrl-btn" id="btn-prev" aria-label="Previous scene">←</button>
        <button type="button" class="ctrl-btn" id="btn-play" aria-label="Pause presentation">❚❚</button>
        <button type="button" class="ctrl-btn" id="btn-next" aria-label="Next scene">→</button>
      </div>
      <div class="controls-center">
        <div class="progress-track"><div class="progress-fill" id="progress-fill"></div></div>
        <div class="scene-dots" id="scene-dots"></div>
      </div>
      <div class="controls-right">
        <span class="scene-counter" id="scene-counter">1 / 12</span>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-mute" aria-label="Mute narration">Mute</button>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-restart" aria-label="Restart">Restart</button>
      </div>
    </footer>`}function _(){return`
    <section class="screen screen--presentation" id="presentation-screen" hidden>
      <header class="topbar">
        <div class="topbar-brand"><span class="brand-dot"></span> Strata Workflow App</div>
        <div class="topbar-meta">Sales Demonstration</div>
      </header>
      <main class="stage" id="stage"></main>
      ${H()}
    </section>`}function z(){return`
    <div class="end-overlay" id="end-overlay">
      <div class="end-card">
        <h3>Thank you</h3>
        <p>Strata Workflow App connects your office and field teams—from project planning to signed deliverables.</p>
        <div class="end-actions">
          <button type="button" class="btn btn-primary" id="btn-replay">Replay Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-explore">Explore Scenes</button>
        </div>
      </div>
    </div>`}const t={started:!1,mode:"audio",sceneIndex:0,currentSceneId:0,playing:!1,muted:!1,ended:!1,userPaused:!1};let i=null,y=null,d=0,$=0;const I=new Map,V=document.getElementById("app");function L(e){try{return new URL(e,document.baseURI).href}catch{return e}}function A(e){const n=I.get(e.id);if(n)return n;const s=new Promise(a=>{const r=new Audio(L(e.audio));r.preload="auto";const c=()=>a();r.addEventListener("canplaythrough",c,{once:!0}),r.addEventListener("error",c,{once:!0}),r.load(),setTimeout(c,4e3)});return I.set(e.id,s),s}function G(){return Promise.all(m.map(e=>A(e))).then(()=>{})}function u(){y&&(clearTimeout(y),y=null)}function k(){i&&(i.pause(),i.currentTime=0,i.onended=null,i.onerror=null,i=null)}function K(){V.innerHTML=U()+_()+z(),Y(),Q(),Z(),J(),ee()}function v(){document.getElementById("end-overlay").classList.remove("is-visible")}function X(){document.getElementById("end-overlay").classList.add("is-visible")}function Y(){document.getElementById("btn-start").addEventListener("click",()=>void P("audio")),document.getElementById("btn-start-muted").addEventListener("click",()=>void P("muted"))}async function P(e){t.started=!0,t.mode=e,t.muted=e==="muted",t.sceneIndex=0,t.playing=!0,t.ended=!1,t.userPaused=!1,document.getElementById("opening-screen").hidden=!0,document.getElementById("presentation-screen").hidden=!1,document.getElementById("controls").hidden=!1,v(),e==="audio"&&!t.muted&&await G(),F(),E(0,!0)}function Q(){const e=document.getElementById("scene-dots");e.innerHTML=m.map((n,s)=>`<button type="button" class="scene-dot" data-index="${s}" aria-label="Go to scene ${s+1}"></button>`).join(""),e.querySelectorAll(".scene-dot").forEach(n=>{n.addEventListener("click",()=>{const s=Number(n.dataset.index);l(s,!0)})})}function Z(){document.getElementById("btn-prev").addEventListener("click",()=>l(t.sceneIndex-1,!0)),document.getElementById("btn-next").addEventListener("click",()=>l(t.sceneIndex+1,!0)),document.getElementById("btn-play").addEventListener("click",M),document.getElementById("btn-mute").addEventListener("click",C),document.getElementById("btn-restart").addEventListener("click",S),document.getElementById("btn-replay").addEventListener("click",S),document.getElementById("btn-explore").addEventListener("click",()=>{t.ended=!1,v(),t.playing=!1,h()}),window.addEventListener("keydown",e=>{t.started&&(e.key==="ArrowRight"||e.key===" "?(e.preventDefault(),t.ended?S():l(t.sceneIndex+1,!0)):e.key==="ArrowLeft"?(e.preventDefault(),l(t.sceneIndex-1,!0)):e.key==="p"||e.key==="P"?M():(e.key==="m"||e.key==="M")&&C())})}function J(){const e=()=>document.getElementById("stage");e().addEventListener("touchstart",n=>{var s;$=((s=n.changedTouches[0])==null?void 0:s.clientX)??0},{passive:!0}),e().addEventListener("touchend",n=>{var a;if(!t.started)return;const s=(((a=n.changedTouches[0])==null?void 0:a.clientX)??0)-$;Math.abs(s)<50||(s<0?l(t.sceneIndex+1,!0):l(t.sceneIndex-1,!0))},{passive:!0})}function ee(){document.getElementById("stage").addEventListener("click",e=>{const n=e.target.closest(".hotspot");n&&(n.classList.toggle("is-active"),document.querySelectorAll(".hotspot.is-active").forEach(s=>{s!==n&&s.classList.remove("is-active")}))})}function w(){return m[t.sceneIndex]}function l(e,n=!1){if(e<0||e>=f){e>=f&&T();return}n&&(t.userPaused=!t.playing),E(e,n)}function E(e,n){u(),k(),cancelAnimationFrame(d),t.sceneIndex=e,t.ended=!1,v();const s=w();t.currentSceneId=s.id;const a=document.getElementById("stage");a.innerHTML=j(s),a.dataset.visual=s.visual,ne(),se(),ie(),requestAnimationFrame(()=>{var r;(r=a.querySelector(".scene-inner"))==null||r.classList.add("is-visible")}),n&&t.playing&&!t.userPaused?x(s):p(0)}function x(e){u(),k();const n=D[e.id]??14e3;t.mode==="audio"&&!t.muted?A(e).then(()=>{if(t.currentSceneId!==e.id)return;i=new Audio(L(e.audio)),i.volume=1,i.preload="auto";const s=()=>B(600);i.onended=s,i.onerror=()=>b(n,s);const a=()=>{i&&i.play().then(()=>te(i)).catch(()=>b(n,s))};i.readyState>=HTMLMediaElement.HAVE_ENOUGH_DATA?a():(i.addEventListener("canplaythrough",a,{once:!0}),i.addEventListener("error",()=>b(n,s),{once:!0}),i.load())}):b(n,()=>B(400))}function te(e){const n=()=>{if(!i||i!==e)return;const s=e.duration;Number.isFinite(s)&&s>0&&p(e.currentTime/s),d=requestAnimationFrame(n)};d=requestAnimationFrame(n)}function b(e,n){const s=performance.now(),a=r=>{if(!t.playing||t.userPaused){d=requestAnimationFrame(a);return}const c=Math.min(1,(r-s)/e);p(c),c>=1?n():d=requestAnimationFrame(a)};d=requestAnimationFrame(a)}function B(e){u(),!(!t.playing||t.userPaused)&&(y=setTimeout(()=>{t.sceneIndex>=f-1?T():l(t.sceneIndex+1,!1)},e))}function T(){t.ended=!0,t.playing=!1,u(),k(),p(1),h(),X()}function S(){t.ended=!1,t.playing=!0,t.userPaused=!1,v(),h(),E(0,!0)}function M(){t.ended||(t.playing=!t.playing,t.userPaused=!t.playing,h(),t.playing?i&&!t.muted?i.play().catch(()=>{}):x(w()):(u(),i&&i.pause(),cancelAnimationFrame(d)))}function C(){t.mode==="muted"?(t.mode="audio",t.muted=!1):t.muted=!t.muted,F(),t.muted?i&&i.pause():t.playing&&!t.userPaused&&t.started&&x(w())}function F(){const e=document.getElementById("btn-mute");t.mode==="muted"||t.muted?(e.textContent="Unmute",e.classList.add("is-muted")):(e.textContent="Mute",e.classList.remove("is-muted"))}function h(){document.getElementById("btn-play").textContent=t.playing?"❚❚":"▶"}function ne(){document.querySelectorAll(".scene-dot").forEach((e,n)=>{e.classList.toggle("is-active",n===t.sceneIndex),e.classList.toggle("is-done",n<t.sceneIndex)})}function se(){document.getElementById("scene-counter").textContent=`${t.sceneIndex+1} / ${f}`}function ie(){p(0)}function p(e){const n=`${Math.max(0,Math.min(100,e*100))}%`;document.getElementById("progress-fill").style.width=n}K()})();
