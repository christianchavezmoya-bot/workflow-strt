var de=Object.defineProperty;var le=(c,o,d)=>o in c?de(c,o,{enumerable:!0,configurable:!0,writable:!0,value:d}):c[o]=d;var L=(c,o,d)=>le(c,typeof o!="symbol"?o+"":o,d);(function(){"use strict";const c="screenshots/scenes";function o(e,n,s){const a=String(e).padStart(2,"0");return n.map((i,r)=>({src:`${c}/${a}-v${r+1}.png`,label:i,variant:(s==null?void 0:s[r])??(r===3&&e===10?"phone":"desktop")}))}const d=[{id:1,audio:"audio/scene-01.mp3",title:"Strata Workflow App",subtitle:"Field operations for telecom and utility project management",tag:"Welcome",views:o(1,["Operations dashboard","Projects portfolio","Project assets table","Mobile field home"],["desktop","desktop","desktop","phone"])},{id:2,audio:"audio/scene-02.mp3",title:"Built for Field Teams",subtitle:"Technicians and project managers, aligned end to end",tag:"Overview",views:o(2,["Asset health overview","Start Run on asset","Project snapshot","Mobile assets"],["desktop","desktop","desktop","phone"])},{id:3,audio:"audio/scene-03.mp3",title:"One App, Three Deployments",subtitle:"React web · Capacitor mobile · ASP.NET Core API",tag:"Platform",views:o(3,["Navigation & modules","Work instructions","Admin & users","Mobile tab bar"],["desktop","desktop","desktop","phone"])},{id:4,audio:"audio/scene-04.mp3",title:"Projects",subtitle:"Your top-level operational container",tag:"Projects",views:o(4,["Projects list","Expanded project row","Project detail","Workflow actions"])},{id:5,audio:"audio/scene-05.mp3",title:"Assets & Installations",subtitle:"The main field-work surface",tag:"Assets",views:o(5,["Project filter","Asset registry columns","Asset row detail","Inline asset expand"])},{id:6,audio:"audio/scene-06.mp3",title:"Guided Workflows",subtitle:"WorkOrderRunner — the heart of on-site work",tag:"Workflows",views:o(6,["Work instructions library","Run workflow setup","Step-by-step runner","Workflow builder"])},{id:7,audio:"audio/scene-07.mp3",title:"Operations Dashboard",subtitle:"Office-scoped visibility and quick actions",tag:"Dashboard",views:o(7,["Needs attention","Evidence completeness","Technician workload","Dashboard tabs"])},{id:8,audio:"audio/scene-08.mp3",title:"Issues Board",subtitle:"Cross-project issue tracking",tag:"Issues",views:o(8,["Issues board","Blocking KPIs","Issue filters & list","Dashboard alerts"])},{id:9,audio:"audio/scene-09.mp3",title:"Documents & More",subtitle:"Knowledge, admin, and mobile upload",tag:"Supporting",views:o(9,["Document library","Work instructions","Admin console","Tips & tricks"])},{id:10,audio:"audio/scene-10.mp3",title:"Offline-First Mobile",subtitle:"Built for real field conditions",tag:"Offline",views:o(10,["Mobile sync bar","Offline assets","Mobile projects","Desktop sync status"],["phone","phone","phone","desktop"])},{id:11,audio:"audio/scene-11.mp3",title:"Architecture & Security",subtitle:"Layered frontend, flat REST API, role-based auth",tag:"Architecture",views:o(11,["User management","Role permissions","Settings & brand","Secure login"])},{id:12,audio:"audio/scene-12.mp3",title:"Enterprise Ready",subtitle:"Secure, scalable, audit-ready",tag:"Enterprise",views:o(12,["Roles configuration","Permission matrix","Workflow templates","Document control"])},{id:13,audio:"audio/scene-13.mp3",title:"Transform Field Operations",subtitle:"From first install to final sign-off",tag:"Next Steps",views:o(13,["Active project","Asset progress","Regional snapshot","Mobile projects"],["desktop","desktop","desktop","phone"])}],A=d.length,p=4,V={1:17200,2:15300,3:19250,4:17800,5:15950,6:18450,7:15700,8:14250,9:17050,10:19750,11:21550,12:19350,13:13300};function O(e){try{return new URL(e,document.baseURI).href}catch{return e}}class N{constructor(){L(this,"tracks",new Map);L(this,"activeId",null)}async loadAll(n){await Promise.all(n.map(s=>this.loadTrack(s)))}loadTrack(n){return this.tracks.has(n.id)?Promise.resolve():new Promise(s=>{const a=new Audio(O(n.audio));a.preload="auto";const i=()=>{this.tracks.set(n.id,a),s()};a.addEventListener("canplaythrough",i,{once:!0}),a.addEventListener("error",i,{once:!0}),a.load(),setTimeout(i,12e3)})}getTrack(n){return this.tracks.get(n)}stop(){const n=this.activeId!=null?this.tracks.get(this.activeId):null;n&&(n.pause(),n.currentTime=0,n.onended=null,n.onerror=null),this.activeId=null}async play(n){this.stop();const s=this.tracks.get(n);if(!s)return null;this.activeId=n,s.currentTime=0,s.readyState<HTMLMediaElement.HAVE_FUTURE_DATA&&await new Promise(a=>{const i=()=>a();s.addEventListener("canplaythrough",i,{once:!0}),s.addEventListener("error",i,{once:!0}),s.load(),setTimeout(i,5e3)});try{return await s.play(),s}catch{return this.activeId=null,null}}get active(){return this.activeId!=null?this.tracks.get(this.activeId)??null:null}}const l=new N;function W(e,n){return`screenshots/${e.replace(/scenes\/(\d+)-v\d+\.png/,(a,i)=>({"01":"desktop-dashboard.png","02":"desktop-assets.png","03":"desktop-work-instructions.png","04":"desktop-projects.png","05":"desktop-assets.png","06":"desktop-work-instructions.png","07":"desktop-dashboard.png","08":"desktop-issues.png","09":"desktop-documents.png",10:"mobile-dashboard.png",11:"desktop-admin.png",12:"desktop-admin.png",13:"desktop-project-detail.png"})[i]??"desktop-dashboard.png").replace("screenshots/","")}`}function q(e,n,s,a){const i=e.variant??"desktop",r=W(e.src);return`
    <button type="button" class="view-panel${n===0?" is-active":""}" data-view-index="${n}" aria-label="${e.label}" aria-pressed="${n===0}">
      <span class="view-panel-badge">${n+1}</span>
      <span class="view-panel-label">${e.label}</span>
      <figure class="view-panel-frame view-panel-frame--${i}">
        <img
          class="view-panel-img"
          src="${e.src}"
          alt="${e.label}"
          loading="eager"
          decoding="async"
          data-fallback="${r}"
          onerror="if(this.dataset.fallback){this.src=this.dataset.fallback;this.dataset.fallback=''}"
        />
      </figure>
    </button>`}function U(e){const n=e.views.slice(0,p).map((a,i)=>q(a,i,e.id,e.views)).join(""),s=e.views.slice(0,p).map((a,i)=>`<span class="view-dot${i===0?" is-active":""}" data-view-dot="${i}"></span>`).join("");return`
    <div class="view-grid-wrap" data-scene-id="${e.id}">
      <div class="view-grid" id="view-grid">
        ${n}
      </div>
      <div class="view-grid-meta">
        <div class="view-dots" id="view-dots">${s}</div>
        <p class="view-hint">Click a panel to focus · views auto-advance with narration</p>
      </div>
    </div>`}function _(e){return`
    <div class="scene-inner" data-scene-id="${e.id}">
      <header class="scene-copy">
        <span class="scene-tag">${e.tag}</span>
        <h2 class="scene-title">${e.title}</h2>
        <p class="scene-subtitle">${e.subtitle}</p>
      </header>
      <div class="scene-visual scene-visual--app" data-visual="${e.id}">
        ${U(e)}
      </div>
    </div>`}function H(){return`
    <section class="screen screen--opening" id="opening-screen">
      <div class="opening-bg"></div>
      <div class="opening-content">
        <div class="brand-mark">S</div>
        <p class="eyebrow">Customer Presentation · v3</p>
        <h1 class="opening-title">Strata Workflow App</h1>
        <p class="opening-lead">Field operations for telecom &amp; utility teams — projects, assets, workflows, and reports in one platform.</p>
        <div class="opening-actions">
          <button type="button" class="btn btn-primary" id="btn-start">Start Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-start-muted">Start without audio</button>
        </div>
        <p class="opening-note">Each scene shows four live app views matched to the narration.<br/>Best in full screen · use Start-Presentation.bat if the page is blank.</p>
      </div>
    </section>`}function G(){return`
    <footer class="controls" id="controls" hidden>
      <div class="controls-left">
        <button type="button" class="ctrl-btn" id="btn-prev" aria-label="Previous scene">←</button>
        <button type="button" class="ctrl-btn" id="btn-play" aria-label="Pause presentation">❚❚</button>
        <button type="button" class="ctrl-btn" id="btn-next" aria-label="Next scene">→</button>
      </div>
      <div class="controls-center">
        <div class="progress-track"><div class="progress-fill" id="progress-fill"></div></div>
        <div class="scene-dots" id="scene-dots"></div>
      </div>
      <div class="controls-right">
        <span class="scene-counter" id="scene-counter">1 / 13</span>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-mute" aria-label="Mute narration">Mute</button>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-restart" aria-label="Restart">Restart</button>
      </div>
    </footer>`}function K(){return`
    <section class="screen screen--presentation" id="presentation-screen" hidden>
      <header class="topbar">
        <div class="topbar-brand"><span class="brand-dot"></span> Strata Workflow App</div>
        <div class="topbar-meta">Sales Demonstration</div>
      </header>
      <main class="stage" id="stage"></main>
      ${G()}
    </section>`}function X(){return`
    <div class="end-overlay" id="end-overlay">
      <div class="end-card">
        <h3>Thank you</h3>
        <p>Strata Workflow App connects office planners and field technicians — from project setup through signed deliverables and audit-ready reports.</p>
        <div class="end-actions">
          <button type="button" class="btn btn-primary" id="btn-replay">Replay Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-explore">Explore Scenes</button>
        </div>
      </div>
    </div>`}function f(e){document.querySelectorAll(".view-panel").forEach((s,a)=>{const i=a===e;s.classList.toggle("is-active",i),s.setAttribute("aria-pressed",String(i))}),document.querySelectorAll(".view-dot").forEach((s,a)=>{s.classList.toggle("is-active",a===e)})}const t={started:!1,mode:"audio",sceneIndex:0,viewIndex:0,playing:!1,muted:!1,ended:!1,userPaused:!1,playToken:0,userPinnedView:!1};let y=null,h=null,u=0,B=0;const Y=document.getElementById("app");function b(){y&&(clearTimeout(y),y=null)}function v(){h&&(clearInterval(h),h=null)}function z(){Y.innerHTML=H()+K()+X(),Q(),Z(),ee(),te()}function w(){document.getElementById("end-overlay").classList.remove("is-visible")}function J(){document.getElementById("end-overlay").classList.add("is-visible")}function Q(){const e=document.getElementById("btn-start"),n=document.getElementById("btn-start-muted");e.addEventListener("click",async()=>{e.disabled=!0,e.textContent="Loading narration…",await $("audio"),e.disabled=!1,e.textContent="Start Presentation"}),n.addEventListener("click",()=>void $("muted"))}async function $(e){t.started=!0,t.mode=e,t.muted=e==="muted",t.sceneIndex=0,t.viewIndex=0,t.playing=!0,t.ended=!1,t.userPaused=!1,t.userPinnedView=!1,t.playToken++,document.getElementById("opening-screen").hidden=!0,document.getElementById("presentation-screen").hidden=!1,document.getElementById("controls").hidden=!1,w(),e==="audio"&&!t.muted&&await l.loadAll(d),D(),E(0,!0)}function Z(){const e=document.getElementById("scene-dots");e.innerHTML=d.map((n,s)=>`<button type="button" class="scene-dot" data-index="${s}" aria-label="Scene ${s+1}"></button>`).join(""),e.querySelectorAll(".scene-dot").forEach(n=>{n.addEventListener("click",()=>m(Number(n.dataset.index),!0))})}function ee(){document.getElementById("btn-prev").addEventListener("click",()=>m(t.sceneIndex-1,!0)),document.getElementById("btn-next").addEventListener("click",()=>m(t.sceneIndex+1,!0)),document.getElementById("btn-play").addEventListener("click",F),document.getElementById("btn-mute").addEventListener("click",R),document.getElementById("btn-restart").addEventListener("click",T),document.getElementById("btn-replay").addEventListener("click",T),document.getElementById("btn-explore").addEventListener("click",()=>{t.ended=!1,w(),t.playing=!1,P()}),window.addEventListener("keydown",e=>{t.started&&(e.key==="ArrowRight"||e.key===" "?(e.preventDefault(),t.ended?T():m(t.sceneIndex+1,!0)):e.key==="ArrowLeft"?m(t.sceneIndex-1,!0):e.key==="ArrowDown"?M(1,!0):e.key==="ArrowUp"?M(-1,!0):e.key==="p"||e.key==="P"?F():(e.key==="m"||e.key==="M")&&R())})}function te(){document.getElementById("stage").addEventListener("touchstart",e=>{var n;B=((n=e.changedTouches[0])==null?void 0:n.clientX)??0},{passive:!0}),document.getElementById("stage").addEventListener("touchend",e=>{var s;if(!t.started)return;const n=(((s=e.changedTouches[0])==null?void 0:s.clientX)??0)-B;Math.abs(n)<50||m(t.sceneIndex+(n<0?1:-1),!0)},{passive:!0})}function ne(){document.querySelectorAll(".view-panel").forEach(e=>{e.addEventListener("click",()=>{const n=Number(e.dataset.viewIndex??0);t.viewIndex=n,t.userPinnedView=!0,f(n)})})}function M(e,n=!1){n&&(t.userPinnedView=!0);const s=(t.viewIndex+e+p)%p;t.viewIndex=s,f(s)}function j(e,n){if(v(),t.userPinnedView)return;t.viewIndex=0,f(0);const s=Math.max(2800,Math.floor(e/p));h=setInterval(()=>{if(n!==t.playToken||t.userPinnedView||!t.playing||t.userPaused)return;const a=(t.viewIndex+1)%p;t.viewIndex=a,f(a)},s)}function k(){return d[t.sceneIndex]}function m(e,n=!1){if(!(e<0)){if(e>=A){C();return}n&&(t.userPaused=!t.playing),E(e,n||t.playing)}}function E(e,n){b(),v(),l.stop(),cancelAnimationFrame(u),t.playToken++,t.sceneIndex=e,t.viewIndex=0,t.userPinnedView=!1,t.ended=!1,w();const s=k(),a=document.getElementById("stage");a.innerHTML=_(s),ne(),ae(),oe(),re(),requestAnimationFrame(()=>{var i;return(i=a.querySelector(".scene-inner"))==null?void 0:i.classList.add("is-visible")}),n&&t.playing&&!t.userPaused?I(s,t.playToken):(g(0),f(0))}async function I(e,n){b(),v(),l.stop();const s=V[e.id]??16e3;j(s,n);const a=()=>{n===t.playToken&&ie(500)};if(t.mode==="audio"&&!t.muted){const i=await l.play(e.id);if(n!==t.playToken)return;if(i){i.onended=a,i.onerror=()=>S(s,a,n),se(i,n);const r=Number.isFinite(i.duration)&&i.duration>0?i.duration*1e3:s;j(r,n)}else S(s,a,n)}else S(s,a,n)}function se(e,n){const s=()=>{if(n!==t.playToken)return;const a=e.duration;Number.isFinite(a)&&a>0&&g(e.currentTime/a),u=requestAnimationFrame(s)};u=requestAnimationFrame(s)}function S(e,n,s){const a=performance.now(),i=r=>{if(s!==t.playToken)return;if(!t.playing||t.userPaused){u=requestAnimationFrame(i);return}const x=Math.min(1,(r-a)/e);g(x),x>=1?n():u=requestAnimationFrame(i)};u=requestAnimationFrame(i)}function ie(e){b(),!(!t.playing||t.userPaused)&&(y=setTimeout(()=>{t.sceneIndex>=A-1?C():E(t.sceneIndex+1,!0)},e))}function C(){t.ended=!0,t.playing=!1,b(),v(),l.stop(),g(1),P(),J()}function T(){t.ended=!1,t.playing=!0,t.userPaused=!1,t.userPinnedView=!1,w(),P(),E(0,!0)}function F(){if(!t.ended)if(t.playing=!t.playing,t.userPaused=!t.playing,P(),t.playing){const e=l.active;e&&!t.muted?e.play().catch(()=>I(k(),++t.playToken)):I(k(),++t.playToken)}else b(),v(),l.stop(),cancelAnimationFrame(u)}function R(){t.mode==="muted"?(t.mode="audio",t.muted=!1):t.muted=!t.muted,D(),t.muted?l.stop():t.playing&&!t.userPaused&&I(k(),++t.playToken)}function D(){const e=document.getElementById("btn-mute");e.textContent=t.mode==="muted"||t.muted?"Unmute":"Mute",e.classList.toggle("is-muted",t.mode==="muted"||t.muted)}function P(){document.getElementById("btn-play").textContent=t.playing?"❚❚":"▶"}function ae(){document.querySelectorAll(".scene-dot").forEach((e,n)=>{e.classList.toggle("is-active",n===t.sceneIndex),e.classList.toggle("is-done",n<t.sceneIndex)})}function oe(){document.getElementById("scene-counter").textContent=`${t.sceneIndex+1} / ${A}`}function re(){g(0)}function g(e){document.getElementById("progress-fill").style.width=`${Math.max(0,Math.min(100,e*100))}%`}z()})();
