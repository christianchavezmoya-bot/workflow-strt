var te=Object.defineProperty;var ne=(i,r,l)=>r in i?te(i,r,{enumerable:!0,configurable:!0,writable:!0,value:l}):i[r]=l;var x=(i,r,l)=>ne(i,typeof r!="symbol"?r+"":r,l);(function(){"use strict";const i="screenshots",r=[{id:1,audio:"audio/scene-01.mp3",title:"Strata Workflow App",subtitle:"Field operations for telecom and utility project management",tag:"Welcome",bullets:[{text:"Track projects, assets, and field workflows in one place"},{text:"Capture photos, signatures, issues, and reports on site"}],screens:{primary:`${i}/desktop-dashboard.png`,layout:"single"}},{id:2,audio:"audio/scene-02.mp3",title:"Built for Field Teams",subtitle:"Technicians and project managers, aligned end to end",tag:"Overview",bullets:[{text:"Install and inspect assets with guided work instructions"},{text:"Replace scattered checklists, photos, and spreadsheets"}],screens:{primary:`${i}/desktop-project-detail.png`,secondary:`${i}/desktop-projects.png`,layout:"single"}},{id:3,audio:"audio/scene-03.mp3",title:"One App, Three Deployments",subtitle:"React web · Capacitor mobile · ASP.NET Core API",tag:"Platform",bullets:[{text:"Web: React 18, TypeScript, MUI, Vite, Redux"},{text:"Mobile: same bundle on Android and iOS via Capacitor 8"},{text:"Backend: ASP.NET Core 8, EF Core, SQLite, JWT auth"}],screens:{primary:`${i}/desktop-dashboard.png`,secondary:`${i}/mobile-dashboard.png`,layout:"split-platforms"}},{id:4,audio:"audio/scene-04.mp3",title:"Projects",subtitle:"Your top-level operational container",tag:"Projects",bullets:[{text:"Assets, contacts, inspections, documents, delivery profiles"},{text:"Browse, open detail, and manage status from /projects"}],screens:{primary:`${i}/desktop-projects.png`,layout:"single"}},{id:5,audio:"audio/scene-05.mp3",title:"Assets & Installations",subtitle:"The main field-work surface",tag:"Assets",bullets:[{text:"Workflow assignments, live status, documents, and run history"},{text:"Pick a project, find your asset, and Start Run"}],screens:{primary:`${i}/desktop-assets.png`,layout:"single"}},{id:6,audio:"audio/scene-06.mp3",title:"Guided Workflows",subtitle:"WorkOrderRunner — the heart of on-site work",tag:"Workflows",bullets:[{text:"Photos, QR inputs, time tracking, issues, and signatures"},{text:"Blocking issues prevent sign-off; reports generate automatically"}],screens:{primary:`${i}/desktop-workflow-runner.png`,secondary:`${i}/desktop-assets.png`,layout:"single"}},{id:7,audio:"audio/scene-07.mp3",title:"Operations Dashboard",subtitle:"Office-scoped visibility and quick actions",tag:"Dashboard",bullets:[{text:"Open issues, pending signatures, technician workload"},{text:"Evidence completeness, workflow health, resume runs"}],screens:{primary:`${i}/desktop-dashboard.png`,layout:"single"}},{id:8,audio:"audio/scene-08.mp3",title:"Issues Board",subtitle:"Cross-project issue tracking",tag:"Issues",bullets:[{text:"Kanban-style view of blocking and non-blocking problems"},{text:"Assign, resolve, and audit across every project"}],screens:{primary:`${i}/desktop-issues.png`,layout:"single"}},{id:9,audio:"audio/scene-09.mp3",title:"Documents & More",subtitle:"Knowledge, admin, and mobile upload",tag:"Supporting",bullets:[{text:"Document library, work instructions, tips for field staff"},{text:"Admin, settings, profile, and QR mobile upload flows"}],screens:{primary:`${i}/desktop-documents.png`,layout:"single"}},{id:10,audio:"audio/scene-10.mp3",title:"Offline-First Mobile",subtitle:"Built for real field conditions",tag:"Offline",bullets:[{text:"Login prefetch: projects, assets, workflows, and config media"},{text:"Queued writes sync on reconnect with conflict detection"}],screens:{primary:`${i}/mobile-assets.png`,layout:"phone"}},{id:11,audio:"audio/scene-11.mp3",title:"Architecture & Security",subtitle:"Layered frontend, flat REST API, role-based auth",tag:"Architecture",bullets:[{text:"features → services → repositories → Redux store"},{text:"JWT auth, permissions, biometric lock on native apps"}],screens:{primary:`${i}/desktop-admin.png`,layout:"single"}},{id:12,audio:"audio/scene-12.mp3",title:"Enterprise Ready",subtitle:"Secure, scalable, audit-ready",tag:"Enterprise",bullets:[{text:"User management, brand settings, two-factor recovery"},{text:"SQLite with migrations; SSE push for live updates"}],screens:{primary:`${i}/desktop-work-instructions.png`,layout:"single"}},{id:13,audio:"audio/scene-13.mp3",title:"Transform Field Operations",subtitle:"From first install to final sign-off",tag:"Next Steps",bullets:[{text:"One connected workflow for office and field teams"},{text:"Ready to see Strata Workflow App on your projects?"}],screens:{primary:`${i}/desktop-project-detail.png`,layout:"single"}}],l=r.length,B={1:17200,2:15300,3:19250,4:17800,5:15950,6:18450,7:15700,8:14250,9:17050,10:19750,11:21550,12:19350,13:13300};function M(e){try{return new URL(e,document.baseURI).href}catch{return e}}class j{constructor(){x(this,"tracks",new Map);x(this,"activeId",null)}async loadAll(n){await Promise.all(n.map(s=>this.loadTrack(s)))}loadTrack(n){return this.tracks.has(n.id)?Promise.resolve():new Promise(s=>{const a=new Audio(M(n.audio));a.preload="auto";const o=()=>{this.tracks.set(n.id,a),s()};a.addEventListener("canplaythrough",o,{once:!0}),a.addEventListener("error",o,{once:!0}),a.load(),setTimeout(o,12e3)})}getTrack(n){return this.tracks.get(n)}stop(){const n=this.activeId!=null?this.tracks.get(this.activeId):null;n&&(n.pause(),n.currentTime=0,n.onended=null,n.onerror=null),this.activeId=null}async play(n){this.stop();const s=this.tracks.get(n);if(!s)return null;this.activeId=n,s.currentTime=0,s.readyState<HTMLMediaElement.HAVE_FUTURE_DATA&&await new Promise(a=>{const o=()=>a();s.addEventListener("canplaythrough",o,{once:!0}),s.addEventListener("error",o,{once:!0}),s.load(),setTimeout(o,5e3)});try{return await s.play(),s}catch{return this.activeId=null,null}}get active(){return this.activeId!=null?this.tracks.get(this.activeId)??null:null}}const d=new j;function C(e,n){return e.includes("workflow-runner")?e.replace("workflow-runner","assets"):e.includes("project-detail")?e.replace("project-detail","projects"):e}function f(e,n,s){const a=s==="phone"?"app-shot app-shot--phone":"app-shot app-shot--desktop",o=C(e);return`
    <figure class="${a}">
      <div class="app-shot-chrome">
        <span class="app-shot-dot"></span><span class="app-shot-dot"></span><span class="app-shot-dot"></span>
        <span class="app-shot-label">${n}</span>
      </div>
      <div class="app-shot-body">
        <img class="app-shot-img" src="${e}" alt="${n}" loading="eager" decoding="async"
             onerror="if(this.dataset.fallback){this.src=this.dataset.fallback;this.dataset.fallback=''}"
             data-fallback="${o}" />
      </div>
    </figure>`}function F(e){const n=e.screens;return n!=null&&n.primary?n.layout==="split-platforms"&&n.secondary?`
      <div class="app-preview app-preview--split">
        ${f(n.primary,"Desktop web","desktop")}
        ${f(n.secondary,"Mobile app","phone")}
      </div>`:n.layout==="phone"?`
      <div class="app-preview app-preview--phone-center">
        ${f(n.primary,"Mobile field app","phone")}
      </div>`:`
    <div class="app-preview app-preview--desktop">
      ${f(n.primary,"Strata Workflow App","desktop")}
    </div>`:'<div class="app-preview app-preview--empty"><p>Live app preview</p></div>'}function R(e){var n;return(n=e.bullets)!=null&&n.length?`
    <ul class="scene-bullets">
      ${e.bullets.map(s=>`<li>${s.text}</li>`).join("")}
    </ul>`:""}function O(e){return`
    <div class="scene-inner" data-scene-id="${e.id}">
      <header class="scene-copy">
        <span class="scene-tag">${e.tag}</span>
        <h2 class="scene-title">${e.title}</h2>
        <p class="scene-subtitle">${e.subtitle}</p>
        ${R(e)}
      </header>
      <div class="scene-visual scene-visual--app" data-visual="${e.id}">
        ${F(e)}
      </div>
    </div>`}function W(){return`
    <section class="screen screen--opening" id="opening-screen">
      <div class="opening-bg"></div>
      <div class="opening-content">
        <div class="brand-mark">S</div>
        <p class="eyebrow">Customer Presentation · v2</p>
        <h1 class="opening-title">Strata Workflow App</h1>
        <p class="opening-lead">Field operations for telecom &amp; utility teams — projects, assets, workflows, and reports in one platform.</p>
        <div class="opening-actions">
          <button type="button" class="btn btn-primary" id="btn-start">Start Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-start-muted">Start without audio</button>
        </div>
        <p class="opening-note">Narration uses a professional male English voice at natural pace.<br/>Best in full screen · use Start-Presentation.bat if the page is blank.</p>
      </div>
    </section>`}function D(){return`
    <footer class="controls" id="controls" hidden>
      <div class="controls-left">
        <button type="button" class="ctrl-btn" id="btn-prev" aria-label="Previous scene">←</button>
        <button type="button" class="ctrl-btn" id="btn-play" aria-label="Pause presentation">❚❚</button>
        <button type="button" class="ctrl-btn" id="btn-next" aria-label="Next scene">→</button>
      </div>
      <div class="controls-center">
        <div class="progress-track"><div class="progress-fill" id="progress-fill"></div></div>
        <div class="scene-dots" id="scene-dots"></div>
      </div>
      <div class="controls-right">
        <span class="scene-counter" id="scene-counter">1 / 13</span>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-mute" aria-label="Mute narration">Mute</button>
        <button type="button" class="ctrl-btn ctrl-btn--text" id="btn-restart" aria-label="Restart">Restart</button>
      </div>
    </footer>`}function N(){return`
    <section class="screen screen--presentation" id="presentation-screen" hidden>
      <header class="topbar">
        <div class="topbar-brand"><span class="brand-dot"></span> Strata Workflow App</div>
        <div class="topbar-meta">Sales Demonstration</div>
      </header>
      <main class="stage" id="stage"></main>
      ${D()}
    </section>`}function q(){return`
    <div class="end-overlay" id="end-overlay">
      <div class="end-card">
        <h3>Thank you</h3>
        <p>Strata Workflow App connects office planners and field technicians — from project setup through signed deliverables and audit-ready reports.</p>
        <div class="end-actions">
          <button type="button" class="btn btn-primary" id="btn-replay">Replay Presentation</button>
          <button type="button" class="btn btn-secondary" id="btn-explore">Explore Scenes</button>
        </div>
      </div>
    </div>`}const t={started:!1,mode:"audio",sceneIndex:0,playing:!1,muted:!1,ended:!1,userPaused:!1,playToken:0};let g=null,c=0,I=0;const U=document.getElementById("app");function p(){g&&(clearTimeout(g),g=null)}function _(){U.innerHTML=W()+N()+q(),Q(),K(),X(),J()}function y(){document.getElementById("end-overlay").classList.remove("is-visible")}function H(){document.getElementById("end-overlay").classList.add("is-visible")}function Q(){const e=document.getElementById("btn-start"),n=document.getElementById("btn-start-muted");e.addEventListener("click",async()=>{e.disabled=!0,e.textContent="Loading narration…",await S("audio"),e.disabled=!1,e.textContent="Start Presentation"}),n.addEventListener("click",()=>void S("muted"))}async function S(e){t.started=!0,t.mode=e,t.muted=e==="muted",t.sceneIndex=0,t.playing=!0,t.ended=!1,t.userPaused=!1,t.playToken++,document.getElementById("opening-screen").hidden=!0,document.getElementById("presentation-screen").hidden=!1,document.getElementById("controls").hidden=!1,y(),e==="audio"&&!t.muted&&await d.loadAll(r),L(),v(0,!0)}function K(){const e=document.getElementById("scene-dots");e.innerHTML=r.map((n,s)=>`<button type="button" class="scene-dot" data-index="${s}" aria-label="Scene ${s+1}"></button>`).join(""),e.querySelectorAll(".scene-dot").forEach(n=>{n.addEventListener("click",()=>u(Number(n.dataset.index),!0))})}function X(){document.getElementById("btn-prev").addEventListener("click",()=>u(t.sceneIndex-1,!0)),document.getElementById("btn-next").addEventListener("click",()=>u(t.sceneIndex+1,!0)),document.getElementById("btn-play").addEventListener("click",A),document.getElementById("btn-mute").addEventListener("click",$),document.getElementById("btn-restart").addEventListener("click",E),document.getElementById("btn-replay").addEventListener("click",E),document.getElementById("btn-explore").addEventListener("click",()=>{t.ended=!1,y(),t.playing=!1,k()}),window.addEventListener("keydown",e=>{t.started&&(e.key==="ArrowRight"||e.key===" "?(e.preventDefault(),t.ended?E():u(t.sceneIndex+1,!0)):e.key==="ArrowLeft"?u(t.sceneIndex-1,!0):e.key==="p"||e.key==="P"?A():(e.key==="m"||e.key==="M")&&$())})}function J(){document.getElementById("stage").addEventListener("touchstart",e=>{var n;I=((n=e.changedTouches[0])==null?void 0:n.clientX)??0},{passive:!0}),document.getElementById("stage").addEventListener("touchend",e=>{var s;if(!t.started)return;const n=(((s=e.changedTouches[0])==null?void 0:s.clientX)??0)-I;Math.abs(n)<50||u(t.sceneIndex+(n<0?1:-1),!0)},{passive:!0})}function b(){return r[t.sceneIndex]}function u(e,n=!1){if(!(e<0)){if(e>=l){T();return}n&&(t.userPaused=!t.playing),v(e,n||t.playing)}}function v(e,n){p(),d.stop(),cancelAnimationFrame(c),t.playToken++,t.sceneIndex=e,t.ended=!1,y();const s=b(),a=document.getElementById("stage");a.innerHTML=O(s),Y(),z(),Z(),requestAnimationFrame(()=>{var o;return(o=a.querySelector(".scene-inner"))==null?void 0:o.classList.add("is-visible")}),n&&t.playing&&!t.userPaused?h(s,t.playToken):m(0)}async function h(e,n){p(),d.stop();const s=B[e.id]??16e3,a=()=>{n===t.playToken&&G(500)};if(t.mode==="audio"&&!t.muted){const o=await d.play(e.id);if(n!==t.playToken)return;o?(o.onended=a,o.onerror=()=>w(s,a,n),V(o,n)):w(s,a,n)}else w(s,a,n)}function V(e,n){const s=()=>{if(n!==t.playToken)return;const a=e.duration;Number.isFinite(a)&&a>0&&m(e.currentTime/a),c=requestAnimationFrame(s)};c=requestAnimationFrame(s)}function w(e,n,s){const a=performance.now(),o=ee=>{if(s!==t.playToken)return;if(!t.playing||t.userPaused){c=requestAnimationFrame(o);return}const P=Math.min(1,(ee-a)/e);m(P),P>=1?n():c=requestAnimationFrame(o)};c=requestAnimationFrame(o)}function G(e){p(),!(!t.playing||t.userPaused)&&(g=setTimeout(()=>{t.sceneIndex>=l-1?T():v(t.sceneIndex+1,!0)},e))}function T(){t.ended=!0,t.playing=!1,p(),d.stop(),m(1),k(),H()}function E(){t.ended=!1,t.playing=!0,t.userPaused=!1,y(),k(),v(0,!0)}function A(){if(!t.ended)if(t.playing=!t.playing,t.userPaused=!t.playing,k(),t.playing){const e=d.active;e&&!t.muted?e.play().catch(()=>h(b(),++t.playToken)):h(b(),++t.playToken)}else p(),d.stop(),cancelAnimationFrame(c)}function $(){t.mode==="muted"?(t.mode="audio",t.muted=!1):t.muted=!t.muted,L(),t.muted?d.stop():t.playing&&!t.userPaused&&h(b(),++t.playToken)}function L(){const e=document.getElementById("btn-mute");e.textContent=t.mode==="muted"||t.muted?"Unmute":"Mute",e.classList.toggle("is-muted",t.mode==="muted"||t.muted)}function k(){document.getElementById("btn-play").textContent=t.playing?"❚❚":"▶"}function Y(){document.querySelectorAll(".scene-dot").forEach((e,n)=>{e.classList.toggle("is-active",n===t.sceneIndex),e.classList.toggle("is-done",n<t.sceneIndex)})}function z(){document.getElementById("scene-counter").textContent=`${t.sceneIndex+1} / ${l}`}function Z(){m(0)}function m(e){document.getElementById("progress-fill").style.width=`${Math.max(0,Math.min(100,e*100))}%`}_()})();
